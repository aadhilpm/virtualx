class ReportType < ActiveRecord::Base
  has_many :reports
end
