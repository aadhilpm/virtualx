class Randomquestion < ActiveRecord::Base
   serialize   :question_set
end
