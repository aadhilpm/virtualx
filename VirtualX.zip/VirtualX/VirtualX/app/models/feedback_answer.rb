class FeedbackAnswer < ActiveRecord::Base
end
