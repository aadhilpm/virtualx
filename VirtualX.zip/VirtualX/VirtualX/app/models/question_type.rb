class QuestionType < ActiveRecord::Base
  has_many :questions
end
