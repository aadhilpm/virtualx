class Aboutus < ActiveRecord::Base
end
