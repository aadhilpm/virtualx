# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Virtualx::Application.config.secret_token = '25c59073f1d15a8790e1149505b5d3482478cddbc3dbdbb9c5840c15e43742ba23c79d5c3a0d84f09894c454bf8ba7a0bb9a4d8ff77a0785a51749c7c0cf8491'
