# Load the rails application
require File.expand_path('../application', __FILE__)

# Initialize the rails application
Virtualx::Application.initialize!

 Admin = 1
 Examiner = 2
 Qsetter = 3
 Examinee = 4


#config.i18n.default_locale = :en


